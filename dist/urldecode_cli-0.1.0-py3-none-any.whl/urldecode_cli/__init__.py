__name__ = "urldecode_cli"
__version__ = "0.1.0"
__description__ = "CLI tool to quickly decode URL encoded strings"
__authors__ = ["Annie Ehler <annie.ehler.4@gmail.com>"]
__license__ = "GPL-3-or-later"
