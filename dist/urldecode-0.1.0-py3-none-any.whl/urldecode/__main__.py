from .cli import urldecode

def main():
    urldecode()

if __name__ == '__main__':
    main()
